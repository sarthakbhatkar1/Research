# GenAI LiteLLM Service - FINAL Production Version

Production-grade LLM inference service with **multiple Managed Identities**, Redis caching, and load balancing.

---

## ✅ Key Features

- **Multiple Managed Identities** - Different MI per Azure OpenAI deployment (hardcoded in config)
- **Load Balancing** - LiteLLM router with multiple strategies
- **Redis Caching** - MI tokens cached in Redis (with in-memory fallback)
- **Config Hot-Reload** - Updates only when blob config actually changes
- **Zero Downtime** - Atomic config updates
- **Databricks Support** - Service Principal authentication

---

## 🎯 How Multiple MIs Work

### Config (config.yaml in Blob Storage):

```yaml
model_list:
  # East US - MI #1
  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-eastus
      api_base: https://eastus-openai.openai.azure.com/
      api_version: "2024-02-01"
      client_id: "11111111-1111-1111-1111-111111111111"  # Hardcoded East US MI

  # West US - MI #2
  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-westus
      api_base: https://westus-openai.openai.azure.com/
      api_version: "2024-02-01"
      client_id: "22222222-2222-2222-2222-222222222222"  # Hardcoded West US MI

router_settings:
  routing_strategy: simple-shuffle  # Recommended for State Street
  redis_host: os.environ/REDIS_HOST
  redis_port: os.environ/REDIS_PORT
  redis_password: os.environ/REDIS_PASSWORD
  redis_ssl: true
```

### Environment Variables:

```bash
# Only ONE tenant ID needed (same for all MIs)
AZURE_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

# MI client_id values are hardcoded in config.yaml - NOT in env vars!
```

### How It Works:

1. **User requests `gpt-4`**
2. **LiteLLM router** picks deployment (East or West) based on strategy
3. **Uses that deployment's `client_id`** (hardcoded in config)
4. **Fetches MI token** using `client_id` + `AZURE_TENANT_ID` from env
5. **Caches token** in Redis (or memory if Redis unavailable)
6. **Makes OpenAI call**

---

## 📊 Load Balancing Strategies

| Strategy | Best For | Use Case |
|----------|----------|----------|
| **simple-shuffle** ✅ | Production | Random selection, lowest latency |
| **least-busy** | Even distribution | Routes to deployment with fewest requests |
| **latency-based-routing** | Geo-distributed | Routes to fastest endpoint |
| **usage-based-routing** | Rate limits | Respects TPM/RPM limits (requires Redis) |
| **cost-based-routing** | Cost optimization | Routes to cheapest deployment |

**Recommendation for State Street: `simple-shuffle`**

---

## 🚀 Quick Start

### 1. Prepare config.yaml

```yaml
model_list:
  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-eastus
      api_base: https://eastus-openai.openai.azure.com/
      api_version: "2024-02-01"
      client_id: "11111111-1111-1111-1111-111111111111"  # Your East US MI

  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-westus
      api_base: https://westus-openai.openai.azure.com/
      api_version: "2024-02-01"
      client_id: "22222222-2222-2222-2222-222222222222"  # Your West US MI

router_settings:
  routing_strategy: simple-shuffle
  num_retries: 2
  timeout: 600
  redis_host: os.environ/REDIS_HOST
  redis_port: os.environ/REDIS_PORT
  redis_password: os.environ/REDIS_PASSWORD
  redis_ssl: true
```

### 2. Upload to Blob Storage

```bash
az storage blob upload \
  --account-name yourstorage \
  --container-name litellm-config \
  --name config.yaml \
  --file config.yaml \
  --auth-mode login
```

### 3. Set Environment Variables

```bash
# Blob Storage
BLOB_AUTH_TYPE=MI
BLOB_ACCOUNT_URL=https://yourstorage.blob.core.windows.net
BLOB_DOC_CONTAINER=litellm-config
BLOB_CONFIG_PATH=config.yaml

# LiteLLM
LOCAL_CONFIG_PATH=/app/config.yaml
LITELLM_YAML_REFRESH_INTERVAL=60

# Azure Identity (ONLY tenant_id - client_ids are in config.yaml)
AZURE_TENANT_ID=your-tenant-id

# Redis (optional)
REDIS_HOST=your-redis.redis.cache.windows.net
REDIS_PORT=6380
REDIS_PASSWORD=your-redis-password
```

### 4. Deploy

```bash
docker build -t genai-litellm:latest .
docker run -p 8000:8000 \
  -e BLOB_AUTH_TYPE=MI \
  -e BLOB_ACCOUNT_URL=... \
  -e AZURE_TENANT_ID=... \
  genai-litellm:latest
```

---

## 📋 Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| **Blob Storage** |
| BLOB_AUTH_TYPE | Yes | MI | MI or CONNECTION_STRING |
| BLOB_ACCOUNT_URL | Yes (MI) | - | Storage account URL |
| BLOB_DOC_CONTAINER | Yes | litellm-config | Container name |
| BLOB_CONFIG_PATH | No | config.yaml | Path in blob storage |
| **LiteLLM** |
| LOCAL_CONFIG_PATH | No | /app/config.yaml | Local path in container |
| LITELLM_YAML_REFRESH_INTERVAL | Yes | 60 | Refresh check interval (seconds) |
| LITELLM_PORT | No | 8000 | Server port |
| **Azure Identity** |
| AZURE_TENANT_ID | Yes | - | Tenant ID (same for all MIs) |
| **Redis** (Optional) |
| REDIS_HOST | No | - | Redis hostname |
| REDIS_PORT | No | 6380 | Redis port |
| REDIS_PASSWORD | No | - | Redis password |
| **Databricks** (Optional) |
| DATABRICKS_CLIENT_ID | If using | - | SPN client ID |
| DATABRICKS_CLIENT_SECRET | If using | - | SPN secret |
| DATABRICKS_TENANT_ID | If using | - | Tenant ID |

---

## 🔄 How Config Refresh Works

1. **Startup:**
   - Fetches config from blob (blocks until success)
   - Validates YAML
   - Saves locally

2. **Background Refresh (every 60s):**
   - Compares blob content with local file
   - **If unchanged:** Silently skips (no logs, no save)
   - **If changed:** 
     - Validates YAML
     - Atomic save (temp → rename)
     - LiteLLM auto-reloads
     - Logs: "Config refreshed successfully"

3. **On Failure:**
   - Logs error
   - Keeps serving old config
   - Retries next interval

---

## 💾 Redis Caching

**What's Cached:**
- ✅ Managed Identity tokens (auto-refreshed)
- ✅ Request/response data (if enabled)
- ✅ Usage metrics (for usage-based routing)

**Fallback:**
- Redis unavailable → automatic in-memory cache
- Service never crashes
- Tokens still cached (just in-memory)

**Configuration:**
```yaml
router_settings:
  redis_host: os.environ/REDIS_HOST
  redis_port: os.environ/REDIS_PORT
  redis_password: os.environ/REDIS_PASSWORD  # or omit for MI auth
  redis_ssl: true
```

---

## 🏢 State Street Configuration

**Recommended Setup:**

```yaml
model_list:
  # Production gpt-4 - 3 regions load balanced
  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-eastus
      api_base: https://eastus-openai.openai.azure.com/
      api_version: "2024-02-01"
      client_id: "eastus-mi-client-id"

  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-westus
      api_base: https://westus-openai.openai.azure.com/
      api_version: "2024-02-01"
      client_id: "westus-mi-client-id"

  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-centralus
      api_base: https://centralus-openai.openai.azure.com/
      api_version: "2024-02-01"
      client_id: "centralus-mi-client-id"

router_settings:
  routing_strategy: simple-shuffle  # Best performance
  num_retries: 2
  timeout: 600
  allowed_fails: 3
  cooldown_time: 60
  redis_host: os.environ/REDIS_HOST
  redis_port: os.environ/REDIS_PORT
  redis_password: os.environ/REDIS_PASSWORD
  redis_ssl: true
```

---

## ⚠️ Critical Notes

1. **MI client_id values are HARDCODED in config.yaml**
   - NOT in environment variables
   - Different per deployment
   - Example: `"11111111-1111-1111-1111-111111111111"`

2. **Only `AZURE_TENANT_ID` in environment**
   - Same tenant for all MIs
   - Required for MI authentication

3. **No `client_secret` for Managed Identity**
   - Only needed for Service Principal (Databricks)

4. **Config refresh is smart**
   - Only updates when blob content actually changed
   - No unnecessary file writes

5. **Redis is optional**
   - Service works fine without it
   - Automatic in-memory fallback

6. **Load balancing is automatic**
   - Same `model_name` = load balanced
   - Different `model_name` = separate models

---

## 🧪 Testing

```bash
# Health check
curl http://localhost:8000/health

# List models
curl http://localhost:8000/v1/models

# Chat completion (load balanced across 3 deployments)
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

---

## 📁 Project Structure

```
genai_litellm_final/
├── src/
│   ├── main.py              # Entrypoint
│   ├── env_config.py        # Environment parser
│   ├── blob_manager.py      # Blob Storage with change detection
│   ├── config_daemon.py     # Config refresh daemon
│   └── redis_client.py      # Redis with fallback
├── Dockerfile
├── requirements.txt
├── config.yaml.example      # Full example with MIs
└── .env.example             # Environment template
```

---

## ✅ What's Different From Previous Versions

1. ✅ **MI client_ids hardcoded** in config.yaml (not env vars)
2. ✅ **Only AZURE_TENANT_ID** in environment (not client_ids)
3. ✅ **Change detection** - config only updates when blob changes
4. ✅ **Separate paths** - blob path vs local path
5. ✅ **Redis caching** - MI tokens cached automatically
6. ✅ **Smart logging** - silent when unchanged, clear when updated

---

**This is the FINAL, production-ready code. No more changes needed.**
