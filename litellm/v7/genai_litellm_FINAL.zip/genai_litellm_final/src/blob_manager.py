"""Azure Blob Storage manager for config.yaml fetching."""
import logging
import os
import yaml

logger = logging.getLogger(__name__)


class BlobConfigManager:
    """
    Manages fetching config.yaml from Azure Blob Storage.
    
    Features:
    - MI or connection string auth
    - Atomic file updates (temp -> rename)
    - YAML validation
    - Change detection (only updates if blob content changed)
    """

    def __init__(self, config):
        self.config = config
        self.blob_service_client = None
        self.container_client = None
        self._initialize_blob_client()

    def _initialize_blob_client(self):
        """Initialize Azure Blob Storage client."""
        try:
            from azure.storage.blob import BlobServiceClient
            from azure.identity import DefaultAzureCredential, ManagedIdentityCredential

            if self.config.auth_type == "MI":
                if self.config.mi_client_id:
                    logger.info(f"Blob: Using User-Assigned MI: {self.config.mi_client_id[:8]}...")
                    credential = ManagedIdentityCredential(client_id=self.config.mi_client_id)
                else:
                    logger.info("Blob: Using System-Assigned MI")
                    credential = DefaultAzureCredential()

                self.blob_service_client = BlobServiceClient(
                    account_url=self.config.account_url,
                    credential=credential
                )
            
            elif self.config.auth_type == "CONNECTION_STRING":
                logger.info("Blob: Using connection string authentication")
                self.blob_service_client = BlobServiceClient.from_connection_string(
                    self.config.connection_string
                )
            
            else:
                raise ValueError(f"Invalid BLOB_AUTH_TYPE: {self.config.auth_type}")

            self.container_client = self.blob_service_client.get_container_client(
                self.config.container
            )

            logger.info(f"✓ Blob storage initialized: {self.config.container}/{self.config.blob_path}")

        except Exception as e:
            logger.error(f"Failed to initialize blob client: {e}")
            raise

    def fetch_config(self, local_path: str, force: bool = False) -> bool:
        """
        Fetch config.yaml from blob and save locally ONLY if changed.
        
        Args:
            local_path: Path to save config locally
            force: If True, always save even if unchanged (for initial fetch)
        
        Returns:
            True if config was updated, False if unchanged
        """
        try:
            blob_client = self.container_client.get_blob_client(self.config.blob_path)
            
            # Download to memory
            blob_data = blob_client.download_blob()
            new_config_content = blob_data.readall()
            
            # Validate YAML
            try:
                yaml.safe_load(new_config_content)
            except yaml.YAMLError as e:
                logger.error(f"Invalid YAML in blob: {e}")
                return False
            
            # Check if config actually changed
            if not force and os.path.exists(local_path):
                with open(local_path, 'rb') as f:
                    current_config = f.read()
                
                if current_config == new_config_content:
                    logger.debug("Config unchanged, skipping update")
                    return False
            
            # Config changed or force=True - update it
            logger.info(f"Config changed, updating from blob:{self.config.blob_path} to local:{local_path}")
            
            # Atomic write: temp -> rename
            temp_path = f"{local_path}.tmp"
            with open(temp_path, 'wb') as f:
                f.write(new_config_content)
            
            os.replace(temp_path, local_path)
            
            logger.info(f"✓ Config updated successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to fetch config from blob:{self.config.blob_path}: {e}")
            return False

    def validate_config_file(self, path: str) -> bool:
        """Validate config file exists and has valid structure."""
        try:
            if not os.path.exists(path):
                logger.warning(f"Config file not found: {path}")
                return False
            
            with open(path, 'r') as f:
                config_data = yaml.safe_load(f)
            
            if not isinstance(config_data, dict):
                logger.error("Config is not a dictionary")
                return False
            
            if "model_list" not in config_data:
                logger.error("Config missing 'model_list'")
                return False
            
            if not isinstance(config_data["model_list"], list):
                logger.error("'model_list' must be a list")
                return False
            
            logger.info(f"✓ Config valid: {len(config_data['model_list'])} models")
            return True
            
        except Exception as e:
            logger.error(f"Config validation error: {e}")
            return False
