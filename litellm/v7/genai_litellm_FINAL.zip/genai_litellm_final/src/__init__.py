"""GenAI LiteLLM Service - Production-grade LLM inference."""
__version__ = "1.0.0"
