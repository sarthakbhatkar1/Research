"""Uploaded guardrail actions: two-layer check (classifier, then a second-opinion reviewer).

This file lives inside the guardrail's zip. NeMo Guardrails loads it by itself, so the
service needs no registration code for it.

One `rails.generate_async(...)` call from the service triggers `rai_review_check`, which
makes up to two guard LLM calls through the same `llm` the service built (GuardrailsLLM):

1. `check_task`   always runs. The verdict is "Yes" (block) or "No" (allow).
2. `review_task`  runs only when call 1 blocks. It writes its reasoning first, then a verdict
                  of "Confirmed" or "FalsePositive" as one line of JSON:
                  {"reason": "...", "verdict": "Confirmed"}

Only the verdict decides the outcome:
- "FalsePositive"            -> the block is overturned and the input is allowed.
- anything else, any error   -> the block stands (fail closed).

The reviewer's reasoning is an intermediate step. It is logged, and it is returned in the
response only when the guardrail config sets `custom_data.rai_expose_review_reason: true`.

The task names are action arguments, so the same action can serve other guardrails (for
example an image check) by passing different tasks from the flow.

Runs unchanged on nemoguardrails 0.19.x and 0.24.x.

Notes on the LLM wrapper this has to live with (GuardrailsLLM._acall):
- For the verdict call it returns only the value of `rai_v1_check_answer` ("Yes" or "No"),
  not the JSON. Both shapes are accepted here.
- A 400 content-filter response comes back as the plain string "yes", or as the repr of a
  dict containing `content_filter_results`. Both are treated as a block.
- The wrapper attaches `self.image` (when the service sets it) to every call, so the review
  call sees the same image as the first call without any code here.
"""

import json
import logging
import re
from typing import Any, Dict, List, Optional

from nemoguardrails.actions.actions import ActionResult, action
from nemoguardrails.context import llm_call_info_var
from nemoguardrails.logging.explain import LLMCallInfo
from nemoguardrails.utils import new_event_dict

try:  # nemoguardrails 0.19.x
    from nemoguardrails.actions.llm.utils import llm_call
except ImportError:  # pragma: no cover - newer layouts
    from nemoguardrails.llm.call import llm_call

log = logging.getLogger(__name__)

DEFAULT_CHECK_TASK = "self_check_input"
DEFAULT_REVIEW_TASK = "self_check_input_review"
EXPOSE_REASON_KEY = "rai_expose_review_reason"


def _user_input(context: Optional[dict], events: Optional[List[dict]]) -> Optional[str]:
    """The text the guard prompts evaluate.

    The service calls `generate_async(prompt=<json string>)`, so NeMo's `user_message` already is
    the whole `{"messages": [...]}` payload. Fall back to the event history if it is missing.
    """
    text = (context or {}).get("user_message")
    if isinstance(text, str) and text.strip():
        return text

    lines: List[str] = []
    for ev in events or []:
        t = ev.get("type")
        if t == "SystemMessage":
            lines.append(f"system: {ev.get('content')}")
        elif t == "UtteranceUserActionFinished":
            lines.append(f"user: {ev.get('final_transcript')}")
        elif t == "StartUtteranceBotAction":
            lines.append(f"assistant: {ev.get('script')}")
    return "\n".join(lines) or None


def _extract_json(text: Any) -> Optional[dict]:
    """Parse a JSON object from an LLM reply, tolerating code fences and stray prose."""
    if not text or not isinstance(text, str):
        return None
    cleaned = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    for candidate in (cleaned, *re.findall(r"\{.*?\}", cleaned, flags=re.DOTALL)):
        try:
            obj = json.loads(candidate)
            if isinstance(obj, dict):
                return obj
        except (ValueError, TypeError):
            continue
    return None


def _normalize(value: Any) -> str:
    """'FalsePositive', 'false positive', 'false_positive' -> 'falsepositive'; 'Confirmed.' -> 'confirmed'."""
    return re.sub(r"[^a-z]", "", str(value or "").lower())


def _is_blocked(raw_verdict: Any) -> bool:
    """True unless the verdict is an explicit "No". Anything unparseable fails closed."""
    text = str(raw_verdict or "").strip()
    obj = _extract_json(text)
    if obj is not None and "rai_v1_check_answer" in obj:
        answer = str(obj["rai_v1_check_answer"])
    else:
        answer = text  # the wrapper may already have reduced the reply to "Yes" / "No"
    return answer.strip().strip("\"'.").lower() != "no"


def _parse_review(raw: Any) -> "tuple[str, str]":
    """Return (normalized verdict, reason) from the reviewer's reply. Verdict is '' when unreadable."""
    verdict: Any = ""
    reason: Any = ""
    obj = _extract_json(raw)
    if obj is not None:
        verdict = obj.get("verdict", "")
        reason = obj.get("reason", "")
    if not verdict and isinstance(raw, str):
        m = re.search(r'"verdict"\s*:\s*"([^"]*)"', raw)
        if m:
            verdict = m.group(1)
    if not reason and isinstance(raw, str):
        m = re.search(r'"reason"\s*:\s*"(.*?)"\s*,\s*"verdict"', raw, flags=re.DOTALL)
        if m:
            reason = m.group(1)
    return _normalize(verdict), str(reason or "").strip()


def _json_string_body(text: str) -> str:
    """Make `text` safe to place between the quotes of a JSON string inside a Colang bot message.

    The Colang runtime reinterprets backslash sequences after variable substitution, which breaks
    the JSON. So this copy has no control characters, no backslashes and no double quotes.
    """
    flat = " ".join(re.sub(r"[\x00-\x1f\x7f]+", " ", text).split())
    return flat.replace("\\", "/").replace('"', "'")


async def _run_task(task: str, prompt_context: Dict[str, Any], llm_task_manager, llms, main_llm, config, fallback_task: str) -> str:
    # A model configured with `type: <task>` wins, then the one for the first-pass task, then the main model.
    model = (llms or {}).get(task) or (llms or {}).get(fallback_task) or main_llm
    prompt = llm_task_manager.render_task_prompt(task=task, context=prompt_context)
    stop = llm_task_manager.get_stop_tokens(task=task)
    max_tokens = llm_task_manager.get_max_tokens(task=task) or 256
    temperature = getattr(config, "lowest_temperature", 0.0) if config is not None else 0.0

    llm_call_info_var.set(LLMCallInfo(task=task))
    response = await llm_call(
        model,
        prompt,
        stop=stop,
        llm_params={"temperature": temperature, "max_tokens": max_tokens},
    )
    # 0.19.x returns a str, newer versions return an object with `.content`.
    return getattr(response, "content", response) or ""


def _expose_reason(config) -> bool:
    return bool((getattr(config, "custom_data", None) or {}).get(EXPOSE_REASON_KEY, False))


def _blocked(reason: str, expose: bool) -> ActionResult:
    shown = _json_string_body(reason) if expose else ""
    return ActionResult(
        return_value=False,
        context_updates={
            "rai_block_reason": reason,
            "rai_block_reason_json": shown,
            "rai_overturn_reason_json": "",
        },
        events=[new_event_dict("mask_prev_user_message", intent="unanswerable message")],
    )


@action(name="rai_review_check")
async def rai_review_check(
    llm_task_manager,
    context: Optional[dict] = None,
    events: Optional[List[dict]] = None,
    llm=None,
    llms: Optional[dict] = None,
    config=None,
    check_task: str = DEFAULT_CHECK_TASK,
    review_task: str = DEFAULT_REVIEW_TASK,
    require_input: bool = True,
    **kwargs,
):
    """Returns True if the input is allowed, False if it is blocked.

    Args set from the flow: `check_task` and `review_task` name the prompts in prompts.yml.
    `require_input=False` is for checks that do not evaluate text (for example an image check),
    where an empty text input is normal.
    """
    expose = _expose_reason(config)
    user_input = _user_input(context, events)
    if user_input is None and require_input:
        return _blocked("Input blocked by Responsible AI policy.", expose)

    prompt_context = {"user_input": user_input or ""}

    # Call 1: the verdict. Fails closed on anything that is not an explicit "No".
    raw_verdict = await _run_task(check_task, prompt_context, llm_task_manager, llms, llm, config, check_task)
    log.info("RAI check %s verdict: %r", check_task, raw_verdict)
    if not _is_blocked(raw_verdict):
        return ActionResult(
            return_value=True,
            context_updates={"rai_block_reason_json": "", "rai_overturn_reason_json": ""},
        )

    # The provider's own filter already rejected the content. Re-sending it would only be filtered again.
    if "content_filter_results" in str(raw_verdict):
        return _blocked("Input blocked by the model provider's content filter.", expose)

    # Call 2: a second opinion, only on a block. Any failure or unreadable reply keeps the block.
    try:
        raw_review = await _run_task(review_task, prompt_context, llm_task_manager, llms, llm, config, check_task)
    except Exception:
        log.exception("RAI review call failed; keeping the block.")
        return _blocked("Input blocked by Responsible AI policy.", expose)

    verdict, reason = _parse_review(raw_review)
    log.info("RAI review %s verdict=%r reason=%r", review_task, verdict, reason)

    if verdict == "falsepositive":
        log.warning("RAI review overturned the first-pass block as a false positive. reason=%r", reason)
        return ActionResult(
            return_value=True,
            context_updates={
                "rai_review_overturned": True,
                "rai_block_reason_json": "",
                "rai_overturn_reason_json": _json_string_body(reason) if expose else "",
            },
        )

    if verdict != "confirmed":
        log.warning("RAI review reply was not understood (%r); keeping the block.", raw_review)
    return _blocked(reason or "Input blocked by Responsible AI policy.", expose)
