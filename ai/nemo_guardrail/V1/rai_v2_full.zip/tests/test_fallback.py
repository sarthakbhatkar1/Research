"""Checks the service-side fallback: a guardrail without actions.py gets the internal defaults,
a guardrail with its own actions.py or actions/ package is left alone and wins on any name it defines.

Uses a stand-in `guardrails.utils.default_actions` because the real one imports your repo's modules.
Usage: python test_fallback.py
"""

import asyncio
import logging
import os
import shutil
import sys
import tempfile

import nemoguardrails
from nemoguardrails import LLMRails, RailsConfig

HERE = os.path.dirname(os.path.abspath(__file__))
SERVICE_DIR = os.path.join(HERE, "..", "service")

try:
    import hashlib

    from nemoguardrails.embeddings.providers import fastembed as _fe

    def _vec(d):
        return [b / 255.0 for b in hashlib.sha256(d.encode()).digest()[:16]]

    def _fe_init(self, embedding_model, **kw):
        self.embedding_model = embedding_model
        self.embedding_size = 16

    async def _enc_async(self, docs):
        return [_vec(d) for d in docs]

    _fe.FastEmbedEmbeddingModel.__init__ = _fe_init
    _fe.FastEmbedEmbeddingModel.encode = lambda self, docs: [_vec(d) for d in docs]
    _fe.FastEmbedEmbeddingModel.encode_async = _enc_async
except Exception:
    pass

from langchain_core.language_models.llms import LLM  # noqa: E402


class FakeLLM(LLM):
    @property
    def _llm_type(self):
        return "fake"

    def _call(self, prompt, stop=None, run_manager=None, **kw):
        return "No"

    async def _acall(self, prompt, stop=None, run_manager=None, **kw):
        return "No"


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(text)


# A throwaway copy of the service package layout, importable as guardrails.utils.*
PKG = tempfile.mkdtemp(prefix="svc_pkg_")
write(os.path.join(PKG, "guardrails", "__init__.py"), "")
write(os.path.join(PKG, "guardrails", "utils", "__init__.py"), "")
write(os.path.join(PKG, "marks.py"), "CALLED = []\n")
write(
    os.path.join(PKG, "guardrails", "utils", "default_actions.py"),
    "import marks\n"
    "from nemoguardrails.actions import action\n\n"
    "@action(name='rai_shared')\n"
    "async def default_shared():\n    marks.CALLED.append('default:rai_shared'); return True\n\n"
    "@action(name='rai_default_only')\n"
    "async def default_only():\n    marks.CALLED.append('default:rai_default_only'); return True\n",
)
shutil.copy(os.path.join(SERVICE_DIR, "actions_fallback.py"), os.path.join(PKG, "guardrails", "utils", "actions_fallback.py"))
sys.path.insert(0, PKG)

import marks  # noqa: E402
from guardrails.utils.actions_fallback import ensure_default_actions  # noqa: E402

CONFIG_YML = "models:\n  - type: main\n    engine: openai\n    model: m\nrails:\n  input:\n    flows:\n      - probe flow\n"
FLOWS = (
    'define bot inform done\n  "DONE"\n\n'
    "define flow probe flow\n"
    "  $a = execute rai_shared\n"
    "  $b = execute rai_default_only\n"
    "  bot inform done\n"
)
OWN_ACTIONS = (
    "import marks\n"
    "from nemoguardrails.actions import action\n\n"
    "@action(name='rai_shared')\n"
    "async def own_shared():\n    marks.CALLED.append('own:rai_shared'); return True\n\n"
    "@action(name='rai_default_only')\n"
    "async def own_default_only():\n    marks.CALLED.append('own:rai_default_only'); return True\n"
)


def make(kind):
    d = tempfile.mkdtemp(prefix="cfg_")
    write(os.path.join(d, "config.yml"), CONFIG_YML)
    write(os.path.join(d, "flows.co"), FLOWS)
    if kind == "own_actions_py":
        write(os.path.join(d, "actions.py"), OWN_ACTIONS)
    elif kind == "own_actions_pkg":
        write(os.path.join(d, "actions", "my_actions.py"), OWN_ACTIONS)
    elif kind == "own_plus_defaults":
        # Keeps the defaults and overrides one of them: the later definition in the module wins.
        write(
            os.path.join(d, "actions.py"),
            "from guardrails.utils.default_actions import *  # noqa\n"
            "import marks\nfrom nemoguardrails.actions import action\n\n"
            "@action(name='rai_shared')\n"
            "async def own_shared():\n    marks.CALLED.append('own:rai_shared'); return True\n",
        )
    return d


async def scenario(kind, expect_written, expect_calls):
    marks.CALLED.clear()
    d = make(kind)
    written = ensure_default_actions(d)
    assert written is expect_written, (kind, written)
    rails = LLMRails(RailsConfig.from_path(d), llm=FakeLLM())
    r = await rails.generate_async(prompt="hello")
    assert "DONE" in r, r
    print(f"{kind:18s} stub written={written!s:5s} calls={marks.CALLED}")
    assert marks.CALLED == expect_calls, marks.CALLED
    return d


async def main():
    logging.disable(logging.CRITICAL)
    print("nemoguardrails", nemoguardrails.__version__)
    d = await scenario("none", True, ["default:rai_shared", "default:rai_default_only"])
    assert ensure_default_actions(d) is False  # idempotent: a second call leaves the stub alone
    assert not [f for f in os.listdir(d) if f.endswith(".tmp")], os.listdir(d)
    await scenario("own_actions_py", False, ["own:rai_shared", "own:rai_default_only"])
    await scenario("own_actions_pkg", False, ["own:rai_shared", "own:rai_default_only"])
    await scenario("own_plus_defaults", False, ["own:rai_shared", "default:rai_default_only"])
    print("ALL ASSERTIONS PASSED")


asyncio.run(main())
