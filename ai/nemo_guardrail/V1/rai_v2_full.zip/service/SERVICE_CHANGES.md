# Service changes (grails_service.py)

Three small edits, all in the `check_preload_config == False` branch of `execute_nemo`.
Nothing here names an action.

1. Add the two files next to image_check_action.py:
   - guardrails/utils/default_actions.py
   - guardrails/utils/actions_fallback.py

2. Right before `config = RailsConfig.from_path(config_path)`:

       from guardrails.utils.actions_fallback import ensure_default_actions
       ensure_default_actions(config_path)

3. Delete the seven `rails.register_action(action=...)` lines after `LLMRails(config, llm=llm)`.
   Do this last. Existing guardrails keep working without a re-upload, because their zips have no
   actions.py and so receive the default stub.

A guardrail zip that carries its own `actions.py` (like the two-layer input check) is loaded by NeMo
as is and wins on any name it defines.

Upgrade note for 0.24 (separate change): `rails.llm` is a LangChainLLMAdapter there, so
`rails.llm.image = ...`, `.traceId`, `.userModel` and `.client_attributes` must be set on the
`llm` object the service built (keep a reference to it) or the wrapper will not see them.
