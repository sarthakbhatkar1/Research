"""Gives a guardrail the internal default actions when its zip did not bring its own.

Call ensure_default_actions(config_path) right before RailsConfig.from_path(config_path).
Put it at guardrails/utils/actions_fallback.py.

NeMo loads `actions.py` (or an `actions/` package) from the config folder by itself. This only
writes a tiny actions.py that re-exports guardrails.utils.default_actions when neither exists, so a
guardrail with its own actions.py or actions/ package is never touched. A guardrail that wants the
defaults as well as its own actions adds this line to its actions.py:

    from guardrails.utils.default_actions import *  # noqa
"""

import logging
import os
import tempfile

logger = logging.getLogger(__name__)

DEFAULT_ACTIONS_MODULE = "guardrails.utils.default_actions"
STUB = (
    "# Written by the service because this guardrail has no actions.py of its own.\n"
    f"from {DEFAULT_ACTIONS_MODULE} import *  # noqa: F401,F403\n"
)


def ensure_default_actions(config_path: str) -> bool:
    """Returns True if the default stub was written, False if the guardrail brings its own actions."""
    actions_py = os.path.join(config_path, "actions.py")
    actions_pkg = os.path.join(config_path, "actions")
    if os.path.exists(actions_py) or os.path.isdir(actions_pkg):
        logger.info("Guardrail at %s brings its own actions; internal defaults not added", config_path)
        return False

    # Write to a temp file and rename, so a concurrent loader never sees a half-written file.
    fd, tmp = tempfile.mkstemp(dir=config_path, prefix=".actions_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(STUB)
        os.replace(tmp, actions_py)
    except Exception:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    logger.info("Guardrail at %s has no actions.py; added the internal default actions", config_path)
    return True
