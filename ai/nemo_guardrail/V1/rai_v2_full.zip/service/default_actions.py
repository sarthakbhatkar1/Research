"""Internal default actions, used by any guardrail whose zip has no actions.py of its own.

Importing a function that carries the @action decorator is enough for NeMo to register it, so this
module only re-exports the existing actions. It replaces the explicit rails.register_action(...)
lines in grails_service.py. Put it at guardrails/utils/default_actions.py.
"""

# Seen in the repo (guardrails/utils/):
from guardrails.utils.image_check_action import rai_input_image_check  # noqa: F401
from guardrails.utils.input_check_action import rai_input_safety_check  # noqa: F401

# TODO: add the five actions that grails_service.py registers today. I have not seen their modules:
#   rai_check_hallucination, detect_sensitive_data, detect_sensitive_data_v2,
#   mask_sensitive_data, rai_check_offtopic
# Example: from guardrails.utils.<module> import rai_check_hallucination  # noqa: F401
