"""Uploaded guardrail action: run ONE guard task and return its verdict as a plain word.

This file lives inside the guardrail's zip. NeMo Guardrails loads it by itself, so the
service needs no registration code for it.

The action makes a single LLM call through the `llm` the service built (GuardrailsLLM) and says
nothing about what should happen next. The chain lives in flows.co, where each verdict decides
whether another task runs. Adding a task means adding a prompt to prompts.yml and a few lines to
flows.co. This file does not change.

    $first = execute rai_run_task(task="self_check_input")
    if $first == "allow" ...

Arguments
- task:          name of the prompt in prompts.yml.
- mode:          "classify" (default) for a prompt that answers Yes (block) or No (allow), or
                 "review" for a prompt that answers {"reason": "...", "verdict": "Confirmed" |
                 "FalsePositive"} with the reasoning written first.
- require_input: set False for checks that do not evaluate text (for example an image check).

Returns one of
- classify: "allow" | "block" | "content_filter" | "error"
- review:   "confirmed" | "false_positive" | "unclear" | "error"
Anything unreadable maps to the safe side ("block", "unclear"), and a failed call is "error", so a
flow that only lets input through on an explicit "allow" or "false_positive" fails closed.

The reviewer's reasoning is logged and is never returned in the response, unless the guardrail
config sets `custom_data.rai_expose_review_reason: true`. Then it is placed in the context variable
`rai_reason_json` (already made safe for a JSON string in a Colang bot message).

Runs unchanged on nemoguardrails 0.19.x and 0.24.x.

Notes on the LLM wrapper this has to live with (GuardrailsLLM._acall):
- For a classify call it returns only the value of `rai_v1_check_answer` ("Yes" or "No"), not
  the JSON. Both shapes are accepted here.
- A 400 content-filter response comes back as the plain string "yes", or as the repr of a dict
  containing `content_filter_results`. The dict form is reported as "content_filter" because the
  provider already rejected the content and a second call would only be filtered again.
- The wrapper attaches `self.image` (when the service sets it) to every call, so every task sees
  the same image without any code here.
"""

import json
import logging
import re
from typing import Any, Dict, List, Optional

from nemoguardrails.actions.actions import ActionResult, action
from nemoguardrails.context import llm_call_info_var
from nemoguardrails.logging.explain import LLMCallInfo

try:  # nemoguardrails 0.19.x
    from nemoguardrails.actions.llm.utils import llm_call
except ImportError:  # pragma: no cover - newer layouts
    from nemoguardrails.llm.call import llm_call

log = logging.getLogger(__name__)

EXPOSE_REASON_KEY = "rai_expose_review_reason"


def _user_input(context: Optional[dict], events: Optional[List[dict]]) -> Optional[str]:
    """The text the guard prompts evaluate.

    The service calls `generate_async(prompt=<json string>)`, so NeMo's `user_message` already is
    the whole `{"messages": [...]}` payload. Fall back to the event history if it is missing.
    """
    text = (context or {}).get("user_message")
    if isinstance(text, str) and text.strip():
        return text

    lines: List[str] = []
    for ev in events or []:
        t = ev.get("type")
        if t == "SystemMessage":
            lines.append(f"system: {ev.get('content')}")
        elif t == "UtteranceUserActionFinished":
            lines.append(f"user: {ev.get('final_transcript')}")
        elif t == "StartUtteranceBotAction":
            lines.append(f"assistant: {ev.get('script')}")
    return "\n".join(lines) or None


def _extract_json(text: Any) -> Optional[dict]:
    """Parse a JSON object from an LLM reply, tolerating code fences and stray prose."""
    if not text or not isinstance(text, str):
        return None
    cleaned = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    for candidate in (cleaned, *re.findall(r"\{.*?\}", cleaned, flags=re.DOTALL)):
        try:
            obj = json.loads(candidate)
            if isinstance(obj, dict):
                return obj
        except (ValueError, TypeError):
            continue
    return None


def _normalize(value: Any) -> str:
    """'FalsePositive', 'false positive', 'false_positive' -> 'falsepositive'; 'Confirmed.' -> 'confirmed'."""
    return re.sub(r"[^a-z]", "", str(value or "").lower())


def _is_blocked(raw_verdict: Any) -> bool:
    """True unless the verdict is an explicit "No". Anything unparseable fails closed."""
    text = str(raw_verdict or "").strip()
    obj = _extract_json(text)
    if obj is not None and "rai_v1_check_answer" in obj:
        answer = str(obj["rai_v1_check_answer"])
    else:
        answer = text  # the wrapper may already have reduced the reply to "Yes" / "No"
    return answer.strip().strip("\"'.").lower() != "no"


def _parse_review(raw: Any) -> "tuple[str, str]":
    """Return (normalized verdict, reason) from the reviewer's reply. Verdict is '' when unreadable."""
    verdict: Any = ""
    reason: Any = ""
    obj = _extract_json(raw)
    if obj is not None:
        verdict = obj.get("verdict", "")
        reason = obj.get("reason", "")
    if not verdict and isinstance(raw, str):
        m = re.search(r'"verdict"\s*:\s*"([^"]*)"', raw)
        if m:
            verdict = m.group(1)
    if not reason and isinstance(raw, str):
        m = re.search(r'"reason"\s*:\s*"(.*?)"\s*,\s*"verdict"', raw, flags=re.DOTALL)
        if m:
            reason = m.group(1)
    return _normalize(verdict), str(reason or "").strip()


def _json_string_body(text: str) -> str:
    """Make `text` safe to place between the quotes of a JSON string inside a Colang bot message.

    The Colang runtime reinterprets backslash sequences after variable substitution, which breaks
    the JSON. So this copy has no control characters, no backslashes and no double quotes.
    """
    flat = " ".join(re.sub(r"[\x00-\x1f\x7f]+", " ", text).split())
    return flat.replace("\\", "/").replace('"', "'")


async def _call_task(task: str, prompt_context: Dict[str, Any], llm_task_manager, llms, main_llm, config) -> str:
    # A model configured with `type: <task>` wins, otherwise the main model is used.
    model = (llms or {}).get(task) or main_llm
    prompt = llm_task_manager.render_task_prompt(task=task, context=prompt_context)
    stop = llm_task_manager.get_stop_tokens(task=task)
    max_tokens = llm_task_manager.get_max_tokens(task=task) or 256
    temperature = getattr(config, "lowest_temperature", 0.0) if config is not None else 0.0

    llm_call_info_var.set(LLMCallInfo(task=task))
    response = await llm_call(
        model,
        prompt,
        stop=stop,
        llm_params={"temperature": temperature, "max_tokens": max_tokens},
    )
    # 0.19.x returns a str, newer versions return an object with `.content`.
    return getattr(response, "content", response) or ""


def _expose_reason(config) -> bool:
    return bool((getattr(config, "custom_data", None) or {}).get(EXPOSE_REASON_KEY, False))


def _result(verdict: str, context: Optional[dict], reason_json: Optional[str] = None) -> ActionResult:
    """Return the verdict word. `rai_reason_json` is always defined so bot messages can use it."""
    kept = (context or {}).get("rai_reason_json", "")
    return ActionResult(
        return_value=verdict,
        context_updates={"rai_reason_json": kept if reason_json is None else reason_json},
    )


@action(name="rai_run_task")
async def rai_run_task(
    llm_task_manager,
    context: Optional[dict] = None,
    events: Optional[List[dict]] = None,
    llm=None,
    llms: Optional[dict] = None,
    config=None,
    task: str = "self_check_input",
    mode: str = "classify",
    require_input: bool = True,
    **kwargs,
):
    """Runs one guard task through the LLM and returns its verdict word (see the module docstring)."""
    is_review = mode == "review"
    error_word = "error"

    user_input = _user_input(context, events)
    if user_input is None and require_input:
        log.warning("RAI task %s: no input text to evaluate", task)
        return _result("block" if not is_review else "unclear", context)

    try:
        raw = await _call_task(task, {"user_input": user_input or ""}, llm_task_manager, llms, llm, config)
    except Exception:
        log.exception("RAI task %s failed", task)
        return _result(error_word, context)

    if not is_review:
        log.info("RAI task %s verdict: %r", task, raw)
        if "content_filter_results" in str(raw):
            return _result("content_filter", context)
        return _result("block" if _is_blocked(raw) else "allow", context)

    verdict, reason = _parse_review(raw)
    log.info("RAI task %s verdict=%r reason=%r", task, verdict, reason)
    shown = _json_string_body(reason) if (reason and _expose_reason(config)) else None
    if verdict == "falsepositive":
        log.warning("RAI task %s overturned the block as a false positive. reason=%r", task, reason)
        return _result("false_positive", context, shown)
    if verdict == "confirmed":
        return _result("confirmed", context, shown)
    log.warning("RAI task %s reply was not understood: %r", task, raw)
    return _result("unclear", context)
